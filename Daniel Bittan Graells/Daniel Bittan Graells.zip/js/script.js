"use strict"

document.getElementById("cookies").innerHTML=document.cookie;